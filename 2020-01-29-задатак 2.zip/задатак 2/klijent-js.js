$(document).ready(function(){
    $('#korisnicka-forma').submit(function(){
        let x1 = Number.parseFloat($("#x1").val());
        let x2 = Number.parseFloat($("#x2").val());
        let x3 = Number.parseFloat($("#x3").val());
        let y1 = Number.parseFloat($("#y1").val());
        let y2 = Number.parseFloat($("#y2").val());
        let y3 = Number.parseFloat($("#y3").val());
        if(isNaN(x1) || isNaN(x2) || isNaN(x3) || isNaN(y1) || isNaN(y2) || isNaN(y3)){
            $('#p-error').text('Greska! koordinate tjemena nisu validno unesene.');
            return false;
        }
        if(!($('#checkbox-povrsina').is(':checked') || $('#checkbox-obim').is(':checked'))){
            $('#p-error').text('Greska! Odaberite povrsinu ili obim.');
            return false;
        }
        
        let podaci = {x1, y1, x2, y2, x3, y3};
        podaci["povrsina"] = false;
        podaci["obim"] = false;

        if($('#checkbox-povrsina').is(':checked'))
            podaci["povrsina"] = true;
        if($('#checkbox-obim').is(':checked'))
            podaci["obim"] = true;

        $('#p-error').text('');
        let url = "http://localhost:3000";
        
        // slanje podataka ka serveru
        $.ajax(url, {
            method: "GET",
            data: podaci,
            success: function (data) 
            {
                $('.uspjesan-rezultat').css('display', 'none');
                $('#p-uspjesan-rezultat').css('display', 'block');
                $('#poruka').text("");
                $("#x1").val('');
                $("#x2").val('');
                $("#x3").val('');
                $("#y1").val('');
                $("#y2").val('');
                $("#y3").val('');
                $('#div-rezultat').css('display', 'block');
                $('#div-forma').css('display', 'none');

                if(data["povrsina"] != "-1"){
                    $('#povrsina').val(data["povrsina"]);
                    $("#div-povrsina").css('display', 'block');
                }
                
                if(data["obim"] != "-1"){
                    $('#obim').val(data["obim"]);
                    $("#div-obim").css('display', 'block');
                }
            },
            error: function () 
            {
                $('#div-rezultat').css('display', 'block');
                $('#div-forma').css('pointer-events', 'none');
                $('#poruka').text("Greska u komunikaciji sa serverom");
                $('.uspjesan-rezultat').css('display', 'none');
            }
        });

        return false;
    });

    $('#btn-zatvori-rezultat').click(function(){
        $('#div-rezultat').css('display', 'none');
        $('#div-forma').css('pointer-events', 'all');
        $('#div-forma').css('display', 'block');
        $('.uspjesan-rezultat').css('display', 'none');
    });
});