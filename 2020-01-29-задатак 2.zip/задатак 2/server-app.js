function duzina_stranica(podaci)
{
	let a = Math.sqrt((podaci['x1'] - podaci['x3'])*(podaci['x1'] - podaci['x3']) + (podaci['y1'] - podaci['y3'])*(podaci['y1'] - podaci['y3']));
	let b = Math.sqrt((podaci['x1'] - podaci['x2'])*(podaci['x1'] - podaci['x2']) + (podaci['y1'] - podaci['y2'])*(podaci['y1'] - podaci['y2']));
	let c = Math.sqrt((podaci['x2'] - podaci['x3'])*(podaci['x2'] - podaci['x3']) + (podaci['y2'] - podaci['y3'])*(podaci['y2'] - podaci['y3']));
	
	return {a, b, c};
}


function povrsina_trougla(podaci){
    let {a, b, c} =  duzina_stranica(podaci);
	let s = (a + b + c) / 2;
	let P = Math.sqrt(s*(s - a)*(s - b)*(s - c));
	return P;
}

function obim_trougla(podaci){
    let {a, b, c} =  duzina_stranica(podaci);
	return a + b + c;
}

let obj_exports = {povrsina_trougla, obim_trougla};

module.exports = obj_exports;