const http = require('http');
const url = require('url');
const app = require('./server-app.js');

const server = http.createServer();

// osluskivac za zahtjev od klijenta
server.on('request', function(req, res) {
    let teloOdgovora = {};
    let statusniKod = 200;

    let method = req.method;

    if (method === 'GET') 
    {
        // Izdvajanje podataka iz zahteva
        let urlString = req.url;
        let urlObj = url.parse(urlString, true);
        let data = urlObj.query;

        if(data["povrsina"]==="true")
            teloOdgovora["povrsina"] = app.povrsina_trougla(data);
        else
            teloOdgovora["povrsina"] = -1;

        if(data["obim"]==="true")
            teloOdgovora["obim"] = app.obim_trougla(data);
        else
            teloOdgovora["obim"] = -1;

        res.setHeader('Content-Type', 'application/json');
    }
    else if (method == 'OPTIONS') 
    {
        res.setHeader('Allow', 'OPTIONS, GET');
    }
    else 
    {
        statusniKod = 405;
        res.setHeader('Allow', 'OPTIONS, GET');
    }

    res.writeHead(statusniKod, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.write(JSON.stringify(teloOdgovora));
    res.end();
});

const port = 3000;
server.listen(port);

server.once('listening', function() {
    console.log(`http://localhost:${port}`);
});
